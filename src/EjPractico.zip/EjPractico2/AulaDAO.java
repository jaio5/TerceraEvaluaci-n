package EjPractico2;

public class AulaDAO {
	Conexion conexion;
}
