package EjPractico2;

import java.util.Date;

public class Doctor {
	
	private Date anyoTesis;
	private String tituloTesis;
	private String calificacionTesis;
	
}
