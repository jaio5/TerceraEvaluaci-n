package EjPractico2;

import java.sql.Date;
import java.sql.Time;

public class seImparteEn {
	private Time hora;
	private Date fecha;
}
