package EjPractico2;

public class Investigador {
	private int invID;
	private String nombre;
	private String apellidos;
	private String telefono;
	private String correo;
}
