package EjPractico2;

import java.util.Date;

public class Doctorando {
	
	private Date fechaInicioDoctorando;
}
