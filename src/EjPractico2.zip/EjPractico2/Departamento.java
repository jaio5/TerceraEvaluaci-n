package EjPractico2;

public class Departamento {
	private int depID;
	private String descripcion;
	private int numeroInvestigadores;
	
	
}
