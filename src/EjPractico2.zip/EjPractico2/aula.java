package EjPractico2;

public class aula {

	private int aulaID;
	private String numero;
	private int capacidad;
}
