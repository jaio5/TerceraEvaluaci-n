package EjPractico2;

public class articulo {
	
	private int articuloID;
	private String titulo;
	private int numPaginas;
}
